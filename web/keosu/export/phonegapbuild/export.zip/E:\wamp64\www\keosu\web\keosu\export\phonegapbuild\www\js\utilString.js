/*
 * Decode json content
 */
function decodedContent(content){
	//ret.innerHTML = content.replace('/[/\\*]/g', "");
	//console.log(ret.outerHTML);
	return content.replace('/[/\\*]/g', "");
}
